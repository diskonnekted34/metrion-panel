/**
 * AlertService — Async Data Access Layer
 *
 * All methods return Promises so this is a drop-in swap for a real API.
 * To switch from mock → real API, replace the Promise.resolve() bodies
 * with fetch() calls. The rest of the codebase never changes.
 */

import { alertsData, type Alert } from "@/data/alerts";

export const AlertService = {
  async getAll(): Promise<Alert[]> {
    return Promise.resolve(alertsData);
  },

  async getById(id: string): Promise<Alert | undefined> {
    return Promise.resolve(alertsData.find(a => a.id === id));
  },

  async getUnresolved(): Promise<Alert[]> {
    return Promise.resolve(alertsData.filter(a => !a.resolved));
  },

  async getCritical(): Promise<Alert[]> {
    return Promise.resolve(
      alertsData.filter(a => a.category === "critical" && !a.resolved)
    );
  },
};
