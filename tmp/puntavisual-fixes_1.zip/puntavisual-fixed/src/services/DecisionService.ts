/**
 * DecisionService — Async Data Access Layer
 *
 * Returns Promises for drop-in API replacement.
 */

import type { Decision } from "@/data/decisions";
import { decisions as allDecisions } from "@/data/decisions";

export const DecisionService = {
  async getAll(): Promise<Decision[]> {
    return Promise.resolve(allDecisions);
  },

  async getById(id: string): Promise<Decision | undefined> {
    return Promise.resolve(allDecisions.find(d => d.id === id));
  },
};
