/**
 * OkrService — Async Data Access Layer
 *
 * Returns Promises for drop-in API replacement.
 */

import { seedObjectives, seedKeyResults, seedCycles } from "@/core/data/okrSeed";
import type { Objective, KeyResult, OKRCycle } from "@/core/types/okr";

export const OkrService = {
  async getCycles(): Promise<OKRCycle[]> {
    return Promise.resolve(seedCycles);
  },

  async getObjectives(): Promise<Objective[]> {
    return Promise.resolve(seedObjectives);
  },

  async getKeyResults(): Promise<KeyResult[]> {
    return Promise.resolve(seedKeyResults);
  },

  async getObjectiveById(id: string): Promise<Objective | undefined> {
    return Promise.resolve(seedObjectives.find(o => o.id === id));
  },
};
