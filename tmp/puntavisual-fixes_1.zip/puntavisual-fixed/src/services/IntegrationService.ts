/**
 * IntegrationService — Async Data Access Layer
 *
 * Returns Promises for drop-in API replacement.
 */

import { integrations, type Integration } from "@/data/integrations";
import { techConnectors, type TechConnector } from "@/data/techIntegrations";

export const IntegrationService = {
  async getAllBusinessIntegrations(): Promise<Integration[]> {
    return Promise.resolve(integrations);
  },

  async getBusinessIntegrationById(id: string): Promise<Integration | undefined> {
    return Promise.resolve(integrations.find(i => i.id === id));
  },

  async getAllTechConnectors(): Promise<TechConnector[]> {
    return Promise.resolve(techConnectors);
  },

  async getTechConnectorById(id: string): Promise<TechConnector | undefined> {
    return Promise.resolve(techConnectors.find(c => c.id === id));
  },
};
